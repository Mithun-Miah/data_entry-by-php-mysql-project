<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagination</title>
    <style>
        a{
            margin: 10px;
            font-size: 20px;
            text-decoration: none;
            background-color: blue;
            color: white;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>

    <?php
        // Database Connection with mysql database
        $connect = mysqli_connect("localhost", "root", "", "data_entry");
        $limit = 3;

        if(isset($_GET['page'])){
            $page = $_GET['page'];
        }else{
            $page = 1;
        }

        $page = 1;

        $offset = ($page - 1) * $limit;

        $sql = "SELECT * from insert_data LIMIT $limit";
        $result = mysqli_query($connect, $sql);
        while($row = mysqli_fetch_assoc($result)){
            echo "<h2>". $row['email'] ."</h2>";
        }

        // pagination start
        $sql = "SELECT COUNT(*) from insert_data";
        $result = mysqli_query($connect, $sql);
        $total_rows = mysqli_fetch_array($result)[0];
        $total_page = ceil($total_rows / $limit);
    
    ?>

    <ul>
        <a href="?page=1">First</a>

        <?php

            for($i = 1; $i <= $total_page; $i++){
                echo "<a href='?page=$i'>".$i."</a>";
            }
        
        ?>

        <a href="?page=<?php echo $total_page;?>">Last</a>
    </ul>
    
</body>
</html>