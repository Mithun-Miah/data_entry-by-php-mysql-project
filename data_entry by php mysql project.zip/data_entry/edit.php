<?php

// Database Connection with mysql database
$connect = mysqli_connect("localhost", "root", "", "data_entry");

 $id = $_GET['idNo'];

 //For Show Data in Edit page input field
 $read = "SELECT * FROM insert_data WHERE Id=$id";
 $query = mysqli_query($connect, $read);
 $row = mysqli_fetch_array($query);

 if(isset($_POST['edit'])){
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $dept = $_POST['dept'];

        $update = "UPDATE insert_data SET 
        name = '$name', email = '$email', phone = '$phone', dept = '$dept' where Id = $id ";

        $query = mysqli_query($connect, $update);

        if($query){
            echo "<script>alert('Data Update Success')</script>";
        } else{
            echo "<script>alert('Data Update Fail')</script>";
        }
 }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    
    <title>Edit Page</title>

    <style>
        .container{
            width: 500px;
            /* border: 1px solid black; */
            height: 400px;
            margin: 0px auto;
            text-align: center;
            padding: 10px;
        }
        h1 {
            background-color: blue;
            color: white;
            padding: 10px;
            text-align: center;
        }
        form input {
            border: 2px solid green;
            width: 90%;
            padding: 10px;
        }
        select {
            width: 90%;
            padding: 10px;
            border: 2px solid green;
        }

        button {
            padding: 10px;
            width: 90%;
            color: white;
            background-color: green;
            font-size: 18px;
            font-weight: 700;
            letter-spacing: 2px;
            border: none;
            cursor: pointer;
            transition: 0.2s ease-in;
        }
        button:hover {
            background-color: blue;
        }
        table,th,td{
            border: 1px solid black;
            border-collapse: collapse;
            padding: 3px;
        }
    </style>
</head>
<body>
    <h1>Edit Data</h1>
    <div class="container">
    <form method="POST">
    <!-- For Show Data in Edit page input field with value -->
            <input type="text" value="<?php echo $row['name'] ?>" name="name" placeholder="name" require> <br><br>
            <input type="email" value="<?php echo $row['email'] ?>" name="email" placeholder="email" require> <br><br>
            <input type="text" value="<?php echo $row['phone'] ?>" name="phone" placeholder="phone" require> <br><br>
            <select name="dept" id="">
                <option value="CSE">CSE</option>
                <option value="EEE">EEE</option>
                <option value="BBA">BBA</option>
            </select> <br><br>
            <!-- <input type="submit" value="Submit"> -->
            <button name="edit">Update Data</button>
        </form>
    </div>
    
</body>
</html>